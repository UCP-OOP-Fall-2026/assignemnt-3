#include "ResourceManager.h"
#include <iostream>
void ResourceManager::updateStock(Product* p,int amount)const{
    if(!p||amount<=0)return;
    p->quantity+=amount; p->recordStock(p->quantity);
}
void ResourceManager::displayInventory(const Product* products,int count)const{
    for(int i=0;i<count;++i)std::cout<<products[i]<<'\n';
}
