#include "Student.h"
int Student::totalStudents = 0;

Student::Student() : studentID(0), name(""), semester(0), cgpa(0.0) { ++totalStudents; }
Student::Student(int id, const std::string& n, int sem, double gpa)
    : studentID(id), name(n), semester(sem), cgpa(gpa) { ++totalStudents; }
void Student::setDetails(const std::string& n, int sem, double gpa) {
    this->name = n; this->semester = sem; this->cgpa = gpa;
}
int Student::getStudentID() const { return studentID; }
double Student::getCGPA() const { return cgpa; }
void Student::display() const {
    std::cout << "Student ID: " << studentID << "\nName: " << name
              << "\nSemester: " << semester << "\nCGPA: " << cgpa << '\n';
}
void Student::displayThroughPointer(const Student* student) const {
    if (student) student->display();
}
int Student::getTotalStudents() { return totalStudents; }
void Student::displayTotalStudents() {
    std::cout << "Total Registered Students: " << totalStudents << '\n';
}
