#include "Wallet.h"
int Wallet::totalWallets = 0;
Wallet::Wallet() : walletID(0), ownerName(""), balance(0), transactions(nullptr), transactionCount(0) { ++totalWallets; }
Wallet::Wallet(int id, const std::string& owner, double initial)
    : walletID(id), ownerName(owner), balance(initial), transactions(nullptr), transactionCount(0) { ++totalWallets; }
Wallet::Wallet(const Wallet& other)
    : walletID(other.walletID), ownerName(other.ownerName), balance(other.balance),
      transactions(other.transactionCount ? new double[other.transactionCount] : nullptr),
      transactionCount(other.transactionCount) {
    for (int i=0;i<transactionCount;++i) transactions[i]=other.transactions[i];
    ++totalWallets;
}
Wallet::~Wallet() { delete[] transactions; }
void Wallet::appendTransaction(double amount) {
    double* temp = new double[transactionCount+1];
    for (int i=0;i<transactionCount;++i) temp[i]=transactions[i];
    temp[transactionCount]=amount;
    delete[] transactions; transactions=temp; ++transactionCount;
}
void Wallet::deposit(double amount) {
    if (amount<=0) return;
    balance+=amount; appendTransaction(amount);
}
bool Wallet::withdraw(double amount) {
    if (amount<=0 || amount>balance) return false;
    balance-=amount; appendTransaction(-amount); return true;
}
Wallet& Wallet::operator=(const Wallet& other) {
    if (this != &other) {
        double* temp = other.transactionCount ? new double[other.transactionCount] : nullptr;
        for (int i=0;i<other.transactionCount;++i) temp[i]=other.transactions[i];
        delete[] transactions; transactions=temp;
        transactionCount=other.transactionCount; ownerName=other.ownerName; balance=other.balance;
        // walletID is const, so assignment preserves the destination object's ID.
    }
    return *this;
}
int Wallet::getWalletID() const { return walletID; }
double Wallet::getBalance() const { return balance; }
Wallet Wallet::operator+(const Wallet& other) const {
    Wallet result(-1, ownerName + " + " + other.ownerName, balance+other.balance);
    return result;
}
double Wallet::operator-(const Wallet& other) const { return balance-other.balance; }
bool Wallet::operator==(const Wallet& other) const { return balance==other.balance; }
std::ostream& operator<<(std::ostream& out, const Wallet& w) {
    out << "Wallet ID: " << w.walletID << "\nOwner: " << w.ownerName
        << "\nBalance: Rs. " << w.balance << "\nTransactions:";
    if (!w.transactionCount) out << " none";
    for (int i=0;i<w.transactionCount;++i) out << "\n  " << (w.transactions[i]>=0 ? "Deposit: " : "Withdraw: ") << w.transactions[i];
    return out;
}
void compareWallets(const Wallet& a, const Wallet& b) {
    if (a.balance>b.balance) std::cout << "Wallet " << a.walletID << " has a higher balance.\n";
    else if (b.balance>a.balance) std::cout << "Wallet " << b.walletID << " has a higher balance.\n";
    else std::cout << "Both wallets have equal balances.\n";
}
int Wallet::getTotalWallets() { return totalWallets; }
void Wallet::display() const { std::cout << *this << '\n'; }
