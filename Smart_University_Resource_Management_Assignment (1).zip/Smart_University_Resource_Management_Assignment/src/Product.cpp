#include "Product.h"
#include <stdexcept>
int Product::totalProducts=0;
Product::Product() : productID(0), name(""), category(""), price(0), quantity(0), stockHistory(nullptr), historyCount(0) { ++totalProducts; }
Product::Product(int id,const std::string& n,const std::string& c,double p,int q)
 : productID(id),name(n),category(c),price(p),quantity(q),stockHistory(nullptr),historyCount(0) { ++totalProducts; recordStock(q); }
Product::Product(const Product& o)
 : productID(o.productID),name(o.name),category(o.category),price(o.price),quantity(o.quantity),
   stockHistory(o.historyCount?new int[o.historyCount]:nullptr),historyCount(o.historyCount) {
    for(int i=0;i<historyCount;++i) { stockHistory[i]=o.stockHistory[i]; }
    ++totalProducts;
}
Product::~Product(){ delete[] stockHistory; }
void Product::recordStock(int v){
    int* t=new int[historyCount+1]; for(int i=0;i<historyCount;++i)t[i]=stockHistory[i];
    t[historyCount]=v; delete[] stockHistory; stockHistory=t; ++historyCount;
}
Product& Product::operator=(const Product& o){
    if(this!=&o){ int* t=o.historyCount?new int[o.historyCount]:nullptr;
        for(int i=0;i<o.historyCount;++i)t[i]=o.stockHistory[i];
        delete[] stockHistory;stockHistory=t;historyCount=o.historyCount;
        name=o.name;category=o.category;price=o.price;quantity=o.quantity;
        // productID is const; destination ID remains unchanged.
    } return *this;
}
int Product::getProductID()const{return productID;}
double Product::getPrice()const{return price;}
int Product::getQuantity()const{return quantity;}
void Product::display()const{std::cout<<*this<<'\n';}
Product Product::operator+(const Product& o)const{
    if(productID!=o.productID){std::cerr<<"Cannot combine stock: product IDs differ.\n";return Product(*this);}
    Product result(*this); result.quantity+=o.quantity; result.recordStock(result.quantity); return result;
}
bool Product::operator==(const Product& o)const{return productID==o.productID;}
bool Product::operator>(const Product& o)const{return price>o.price;}
Product& Product::operator++(){++quantity;recordStock(quantity);return *this;}
Product Product::operator++(int){Product old(*this);++(*this);return old;}
int Product::operator[](int i)const{if(i<0||i>=historyCount)throw std::out_of_range("Stock history index out of range");return stockHistory[i];}
std::ostream& operator<<(std::ostream& out,const Product& p){
    out<<"Product ID: "<<p.productID<<"\nName: "<<p.name<<"\nCategory: "<<p.category
       <<"\nPrice: Rs. "<<p.price<<"\nQuantity: "<<p.quantity;return out;
}
int Product::getTotalProducts(){return totalProducts;}
