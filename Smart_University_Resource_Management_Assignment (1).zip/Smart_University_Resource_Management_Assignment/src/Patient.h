#pragma once
#include <string>
#include <iostream>
class HospitalManager;
class Patient {
private:
    const int patientID;
    std::string name;
    int age;
    double* dailyCharges;
    int days;
    static int totalPatients;
    friend class HospitalManager;
    friend void compareBills(const Patient& a,const Patient& b);
public:
    Patient();
    Patient(int id,const std::string& name,int age,const double* charges,int days);
    Patient(const Patient& other);
    ~Patient();
    Patient& operator=(const Patient& other);
    double totalBill() const;
    int getPatientID() const;
    int getDays() const;
    double operator+(const Patient& other) const;
    bool operator>(const Patient& other) const;
    bool operator==(const Patient& other) const;
    double operator[](int day) const;
    Patient& operator++();
    Patient operator++(int);
    friend std::ostream& operator<<(std::ostream& out,const Patient& patient);
    static int getTotalPatients();
};
void compareBills(const Patient& a,const Patient& b);
