#pragma once
#include <string>
#include <iostream>

class Student {
private:
    const int studentID;
    std::string name;
    int semester;
    double cgpa;
    static int totalStudents;
public:
    Student();
    Student(int id, const std::string& name, int semester, double cgpa);
    void setDetails(const std::string& name, int semester, double cgpa);
    int getStudentID() const;
    double getCGPA() const;
    void display() const;
    void displayThroughPointer(const Student* student) const;
    static int getTotalStudents();
    static void displayTotalStudents();
};
