#pragma once
#include <string>
#include <iostream>

class Wallet {
private:
    const int walletID;
    std::string ownerName;
    double balance;
    double* transactions;
    int transactionCount;
    static int totalWallets;
    void appendTransaction(double amount);
public:
    Wallet();
    Wallet(int id, const std::string& owner, double initialBalance);
    Wallet(const Wallet& other);
    ~Wallet();
    Wallet& operator=(const Wallet& other);
    void deposit(double amount);
    bool withdraw(double amount);
    int getWalletID() const;
    double getBalance() const;
    void display() const;
    Wallet operator+(const Wallet& other) const;
    double operator-(const Wallet& other) const;
    bool operator==(const Wallet& other) const;
    friend std::ostream& operator<<(std::ostream& out, const Wallet& wallet);
    friend void compareWallets(const Wallet& a, const Wallet& b);
    static int getTotalWallets();
};
