#pragma once
#include <string>
#include <iostream>

class ResourceManager;
class Product {
private:
    const int productID;
    std::string name, category;
    double price;
    int quantity;
    int* stockHistory;
    int historyCount;
    static int totalProducts;
    void recordStock(int value);
    friend class ResourceManager;
public:
    Product();
    Product(int id, const std::string& name, const std::string& category, double price, int quantity);
    Product(const Product& other);
    ~Product();
    Product& operator=(const Product& other);
    int getProductID() const;
    double getPrice() const;
    int getQuantity() const;
    void display() const;
    Product operator+(const Product& other) const;
    bool operator==(const Product& other) const;
    bool operator>(const Product& other) const;
    Product& operator++();
    Product operator++(int);
    int operator[](int index) const;
    friend std::ostream& operator<<(std::ostream& out, const Product& product);
    static int getTotalProducts();
};
