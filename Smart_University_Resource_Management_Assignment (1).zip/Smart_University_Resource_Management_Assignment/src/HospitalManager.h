#pragma once
#include "Patient.h"
class HospitalManager {
public:
    void generateReport(const Patient* patients,int count) const;
};
