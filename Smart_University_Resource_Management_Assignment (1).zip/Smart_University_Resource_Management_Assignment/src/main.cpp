#include <iostream>
#include <limits>
#include <stdexcept>
#include "Student.h"
#include "Wallet.h"
#include "Product.h"
#include "ResourceManager.h"
#include "Patient.h"
#include "HospitalManager.h"

void runQuestion1(){
    int n; std::cout<<"Number of students: "; if(!(std::cin>>n)||n<=0){std::cin.clear();std::cin.ignore(10000,'\n');return;}
    Student** students=new Student*[n];
    for(int i=0;i<n;++i){int id,sem;double gpa;std::string name;
        std::cout<<"\nStudent "<<i+1<<" ID: ";std::cin>>id;
        std::cout<<"Name: ";std::cin>>std::ws;std::getline(std::cin,name);
        std::cout<<"Semester: ";std::cin>>sem;std::cout<<"CGPA: ";std::cin>>gpa;
        students[i]=new Student(id,name,sem,gpa);
    }
    int wanted;std::cout<<"Search student ID: ";std::cin>>wanted;
    bool found=false;for(int i=0;i<n;++i)if(students[i]->getStudentID()==wanted){
        std::cout<<"Student Record Found:\n";students[i]->display();found=true;break;}
    if(!found)std::cout<<"Student not found.\n";
    if(n>0)students[0]->displayThroughPointer(students[0]);
    Student::displayTotalStudents();
    for(int i=0;i<n;++i)delete students[i];
    delete[] students;
}
void runQuestion2(){
    Wallet a(501,"Ali",10000),b(502,"Sara",15000);
    a.deposit(2000);a.withdraw(1000);b.deposit(3000);b.withdraw(500);
    std::cout<<"\nWallet 1:\n"<<a<<"\n\nWallet 2:\n"<<b<<"\n";
    std::cout<<"Comparing wallets: ";compareWallets(a,b);
    Wallet combined=a+b;std::cout<<"Combined balance: Rs. "<<combined.getBalance()<<'\n';
    std::cout<<"Difference: Rs. "<<(b-a)<<'\n';
    std::cout<<"Equal balances? "<<(a==b?"Yes":"No")<<'\n';
    Wallet copy(a);copy.deposit(700);std::cout<<"\nOriginal:\n"<<a<<"\nCopy:\n"<<copy<<'\n';
    Wallet assigned(503,"Temporary",0);assigned=a;std::cout<<"\nAssigned wallet (destination ID preserved):\n"<<assigned<<'\n';
}
void runQuestion3(){
    Product products[4]={Product(101,"Laptop","Electronics",100000,10),
        Product(102,"T-Shirt","Clothing",850,25),Product(103,"C++ Book","Books",500,40),
        Product(104,"Mouse","Electronics",1200,15)};
    double minP,maxP;std::cout<<"Minimum price: ";std::cin>>minP;std::cout<<"Maximum price: ";std::cin>>maxP;
    std::cout<<"Products in price range:\n";for(const Product& p:products)if(p.getPrice()>=minP&&p.getPrice()<=maxP)std::cout<<p<<"\n\n";
    ResourceManager manager;int id,amount;std::cout<<"Product ID to update: ";std::cin>>id;std::cout<<"Quantity to add: ";std::cin>>amount;
    for(Product& p:products)if(p.getProductID()==id)manager.updateStock(&p,amount);
    manager.displayInventory(products,4);
    std::cout<<"Prefix ++ first product quantity:\n";++products[0];std::cout<<products[0]<<'\n';
    Product old=products[0]++;std::cout<<"Postfix returned old quantity: "<<old.getQuantity()<<'\n';
    std::cout<<"Products equal by ID? "<<(products[0]==products[0]?"Yes":"No")<<'\n';
    std::cout<<"Product 0 more expensive than product 1? "<<(products[0]>products[1]?"Yes":"No")<<'\n';
    Product merged=products[0]+products[0];std::cout<<"Combined same-ID stock: "<<merged.getQuantity()<<'\n';
    std::cout<<"Stock history entry 0: "<<products[0][0]<<'\n';
    std::cout<<"Total products: "<<Product::getTotalProducts()<<'\n';
}
void runQuestion4(){
    int n;std::cout<<"Number of patients: ";std::cin>>n;if(n<=0)return;
    Patient** patients=new Patient*[n];
    for(int i=0;i<n;++i){int id,age,days;std::string name;
        std::cout<<"\nPatient "<<i+1<<" ID: ";std::cin>>id;
        std::cout<<"Name: ";std::cin>>std::ws;std::getline(std::cin,name);
        std::cout<<"Age: ";std::cin>>age;std::cout<<"Treatment days: ";std::cin>>days;
        if(days<0) days=0;
        double* charges=days?new double[days]:nullptr;
        for(int d=0;d<days;++d){std::cout<<"Day "<<d+1<<" charge (regular treatment Rs.1000): ";std::cin>>charges[d];}
        patients[i]=new Patient(id,name,age,charges,days);delete[] charges;
    }
    HospitalManager manager;std::cout<<"\nPatient Billing Reports:\n";
    for(int i=0;i<n;++i)manager.generateReport(patients[i],1);
    if(n>=2){compareBills(*patients[0],*patients[1]);
        std::cout<<"Combined bills: Rs. "<<(*patients[0]+*patients[1])<<'\n';}
    if(n>0&&patients[0]->getDays()>0){int day;std::cout<<"Patient 1 day number (1-based): ";std::cin>>day;
        try{std::cout<<"Treatment charge: Rs. "<<(*patients[0])[day-1]<<'\n';}
        catch(const std::out_of_range& e){std::cout<<e.what()<<'\n';}}
    if(n>0){Patient copied(*patients[0]);++copied;
        std::cout<<"Original bill: Rs. "<<patients[0]->totalBill()
                 <<" | Deep-copy bill after prefix ++: Rs. "<<copied.totalBill()<<'\n';}
    std::cout<<"Total registered patients: "<<Patient::getTotalPatients()<<'\n';
    for(int i=0;i<n;++i) { delete patients[i]; }
    delete[] patients;
}
int main(){
    int choice;
    do{std::cout<<"\n===== CSCP2023 Advanced OOP Assignment =====\n"
        <<"1. Student Management\n2. Digital Wallet\n3. Inventory Management\n4. Hospital Billing\n0. Exit\nChoice: ";
        if(!(std::cin>>choice)){std::cin.clear();std::cin.ignore(10000,'\n');continue;}
        switch(choice){case 1:runQuestion1();break;case 2:runQuestion2();break;case 3:runQuestion3();break;case 4:runQuestion4();break;case 0:break;default:std::cout<<"Invalid choice.\n";}
    }while(choice!=0);return 0;
}
