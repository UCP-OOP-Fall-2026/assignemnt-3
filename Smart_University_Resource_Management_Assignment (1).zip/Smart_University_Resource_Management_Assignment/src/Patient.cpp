#include "Patient.h"
#include <stdexcept>
int Patient::totalPatients=0;
Patient::Patient():patientID(0),name(""),age(0),dailyCharges(nullptr),days(0){++totalPatients;}
Patient::Patient(int id,const std::string& n,int a,const double* charges,int count)
 :patientID(id),name(n),age(a),dailyCharges(count>0?new double[count]:nullptr),days(count){
    for(int i=0;i<days;++i) { dailyCharges[i]=charges[i]; }
    ++totalPatients;
}
Patient::Patient(const Patient& o):patientID(o.patientID),name(o.name),age(o.age),
 dailyCharges(o.days?new double[o.days]:nullptr),days(o.days){
    for(int i=0;i<days;++i) { dailyCharges[i]=o.dailyCharges[i]; }
    ++totalPatients;
}
Patient::~Patient(){delete[] dailyCharges;}
Patient& Patient::operator=(const Patient& o){
 if(this!=&o){double* t=o.days?new double[o.days]:nullptr;for(int i=0;i<o.days;++i)t[i]=o.dailyCharges[i];
 delete[] dailyCharges;dailyCharges=t;days=o.days;name=o.name;age=o.age;}
 return *this;
}
double Patient::totalBill()const{double sum=0;for(int i=0;i<days;++i)sum+=dailyCharges[i];return sum;}
int Patient::getPatientID()const{return patientID;}
int Patient::getDays()const{return days;}
double Patient::operator+(const Patient& o)const{return totalBill()+o.totalBill();}
bool Patient::operator>(const Patient& o)const{return totalBill()>o.totalBill();}
bool Patient::operator==(const Patient& o)const{return totalBill()==o.totalBill();}
double Patient::operator[](int day)const{if(day<0||day>=days)throw std::out_of_range("Treatment day out of range");return dailyCharges[day];}
Patient& Patient::operator++(){for(int i=0;i<days;++i)dailyCharges[i]+=100;return *this;}
Patient Patient::operator++(int){Patient old(*this);++(*this);return old;}
std::ostream& operator<<(std::ostream& out,const Patient& p){
 out<<"Patient ID: "<<p.patientID<<"\nName: "<<p.name<<"\nAge: "<<p.age<<"\nDaily charges:";
 for(int i=0;i<p.days;++i)out<<"\n Day "<<i+1<<": Rs. "<<p.dailyCharges[i];
 out<<"\nTotal bill: Rs. "<<p.totalBill();return out;
}
void compareBills(const Patient& a,const Patient& b){
 if(a.totalBill()>b.totalBill())std::cout<<a.name<<" has the higher bill.\n";
 else if(b.totalBill()>a.totalBill())std::cout<<b.name<<" has the higher bill.\n";
 else std::cout<<"Both patients have equal treatment bills.\n";
}
int Patient::getTotalPatients(){return totalPatients;}
