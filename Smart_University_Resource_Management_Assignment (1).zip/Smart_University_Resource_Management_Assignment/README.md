# CSCP2023 – Advanced OOP Programming Assignment

This project implements the four systems in the supplied UCP assignment brief:
1. Student registration and performance
2. Digital wallet and transaction management
3. E-commerce inventory and product management
4. Hospital billing and patient records

## Structure
- `src/Student.h/.cpp`: student records, constant ID, static count, const display and pointer demonstration.
- `src/Wallet.h/.cpp`: dynamic transaction history, deep copy, assignment, friend comparison and operators.
- `src/Product.h/.cpp`: product stock history, overloaded operators and friend `ResourceManager`.
- `src/ResourceManager.h/.cpp`: inventory stock administration.
- `src/Patient.h/.cpp`: dynamic daily charges, deep copy, assignment, operators and `compareBills`.
- `src/HospitalManager.h/.cpp`: friend-class patient reporting.
- `src/main.cpp`: menu-driven demonstrations.
- `docs/Assignment.pdf`: original assignment brief.

## Build (Windows, MinGW g++)
From the project root:
```powershell
g++ -std=c++17 -Wall -Wextra src/*.cpp -o oop_assignment.exe
.\oop_assignment.exe
```
If PowerShell does not expand `src/*.cpp`, use:
```powershell
g++ -std=c++17 -Wall -Wextra src/main.cpp src/Student.cpp src/Wallet.cpp src/Product.cpp src/ResourceManager.cpp src/Patient.cpp src/HospitalManager.cpp -o oop_assignment.exe
```

## Design decisions
- Wallet `+` returns a new wallet whose balance is the sum; `-` returns the balance difference.
- Wallet assignment copies owner, balance and transaction history, while preserving the destination's constant wallet ID.
- Product `+` combines quantities only when product IDs match; `[]` accesses zero-based stock-history entries.
- Product prefix/postfix `++` increases stock by one and records the new quantity.
- Patient `+` returns the sum of two bills; `[]` accesses a zero-based day index.
- Patient prefix/postfix `++` adds Rs. 100 to every day's treatment charge.
- Patient and Wallet copy constructors perform independent deep copies of their dynamic arrays.
- Product also deep-copies its stock history.
- No inheritance or STL containers are used.

## Important implementation note
The brief requires constant IDs and arrays of objects. Because a `const` ID cannot be changed after default construction, the Student and Patient interactive array demonstrations need object construction with IDs known at construction time. Their classes provide parameterized constructors; adapt the arrays to be constructed from input records (or use a pointer array) if your instructor strictly checks entered IDs. The current Q1/Q4 menu includes explanatory demonstrations and fixed sample patient objects; review this behavior and personalize/test it before submission.

Update your name and registration number before submitting. This is a learning implementation; make sure you can explain every class and operator during evaluation.
